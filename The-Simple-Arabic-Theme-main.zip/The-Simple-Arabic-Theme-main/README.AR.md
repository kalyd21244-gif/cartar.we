<p align="center">
  <img src="https://github.com/MohamedAliRashad/The-Simple-Arabic-Theme/blob/main/assets/images/logo.png" />
</p>

العربية | [English](https://github.com/MohamedAliRashad/The-Simple-Arabic-Theme/blob/main/README.md)

### نظرا ان نوع الخط العربى المستعمل سئ فقررت اوفر ما هو افضل من الكتابة … فيديو مشروح فيه كل خطوات التشغيل مع بعض التفاصيل الإضافية 😉

<p align="center">
  <a href="https://www.youtube.com/watch?v=fAVbuk-5PCI">
    <img src="https://img.shields.io/badge/YouTube-%23FF0000.svg?style=for-the-badge&logo=YouTube&logoColor=white"/>
  </a>
</p>
